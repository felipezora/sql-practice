/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Integer.parseInt;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.boleta;
import models.boletaDAO;

/**
 *
 * @author felipe.zora
 */
@WebServlet(urlPatterns = {"/AdminBoleta"})
public class AdminBoleta extends HttpServlet { 
    
    boletaDAO bolDAO = new boletaDAO();
    boleta bol = new boleta();
    
  /*  @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
    throws ServletException, IOException { 
        RequestDispatcher view = request.getRequestDispatcher("Registrar.jsp");
        view.forward(request, response);
    } */
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String n = request.getParameter("sala");
        String c = request.getParameter("pelicula");
        String a = request.getParameter("costo");
        String h = request.getParameter("hora");
        String z = request.getParameter("silla");
        String k = request.getParameter("IDcliente");

        bol.setSala(n);
        bol.setPelicula(c);
        bol.setCosto(a);
        bol.setHora(h);
        bol.setSilla(z);
        bol.setIDcliente(k);
        bolDAO.agregar(bol);
        RequestDispatcher view = request.getRequestDispatcher("reservar.jsp");
        request.setAttribute("mensaje", "Persona agregada satisfactoriamente");
        view.forward(request, response);
    }

}