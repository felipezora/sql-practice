/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author felipe.zora
 */
import db.DB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import models.boleta;

public class boletaDAO {

    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    DB conexion = null;

    public void agregar(boleta p) {

        try {
            conn = conexion.getConexion();
            Statement st = conn.createStatement();
            String query = "INSERT INTO boletas (sala, pelicula, costo, hora, silla, IDcliente) values (?, ?, ?, ?, ?, ?)";
            ps = conn.prepareStatement(query);
            ps.setString(1, p.getSala());
            ps.setString(2, p.getPelicula());
            ps.setString(3, p.getCosto());
            ps.setString(4, p.getHora());
            ps.setString(5, p.getSilla());
            ps.setString(6, p.getIDcliente());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally { try { rs.close(); } catch (Exception e) { /* ignored */ }
        }
    }
    public ArrayList<boleta> obtenerBoletas() {
        ArrayList<boleta> boletas = new ArrayList<boleta>();
        try {
            conn = DB.getConexion();
            String query = "SELECT * FROM boletas";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                boleta boleta = new boleta();
                boleta.setSala(rs.getString("sala"));
                boleta.setPelicula(rs.getString("pelicula"));
                boleta.setCosto(rs.getString("costo"));
                boleta.setHora(rs.getString("hora"));
                boleta.setSilla(rs.getString("silla"));
                boleta.setIDcliente(rs.getString("IDcliente"));
                boletas.add(boleta);
            }

        } catch (Exception e) {
            System.out.println(e);
        }

        return boletas;
    }
}