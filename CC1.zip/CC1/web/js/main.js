/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
window.addEventListener('load', function(){
    document.getElementById('btniniciar').addEventListener('click', function(){
        var nombre = document.getElementById('txtusuario').value;
        var contra = document.getElementById('txtpass').value;
        
        var bandera = false;
        
        if(nombre.length > 0 && contra.length > 0){
            bandera = true;
        }
        if(bandera){
            document.getElementById('forminicio').submit();
        }else{
            alert('Todos los campos son requeridos')  
        }
    });
});
window.addEventListener('load', function(){
    document.getElementById('btnregist').addEventListener('click', function(){
        var nombre = document.getElementById('name').value;
        var apellido = document.getElementById('email').value;
        var usuario = document.getElementById('phone').value;
        var pass = document.getElementById('message').value;
        
        var bandera = false;
        
        if(nombre.length > 0 && apellido.length > 0 && usuario.length > 0 && pass.length > 0){
            bandera = true;
        }
        if(bandera){
            document.getElementById('formregist').submit();
        }else{
            alert('Todos los campos son requeridos')  
        }
    });
});

